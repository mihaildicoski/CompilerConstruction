//class will be the same as TypeChecker.java but with different approach
//will use mutliple functions to check types of syntax tree are valid

public class TypeChecker2 {
    
}
